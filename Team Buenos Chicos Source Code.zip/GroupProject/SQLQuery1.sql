USE [Hackathon]
GO

/****** Object:  Table [dbo].[Academics]    Script Date: 2020-07-03 10:34:10 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Academics](
	[UserName] [varchar](100) NULL,
	[LevelOfEducation] [varchar](200) NULL,
	[InstitutionName] [varchar](500) NULL,
	[ProgramName] [varchar](1000) NULL,
	[GradesOrMarks] [varchar](300) NULL,
	[InstitutionAddress] [varchar](1000) NULL,
	[YearStarted] [varchar](30) NULL,
	[YearCompleted] [varchar](30) NULL
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[Admin](
	[name] [varchar](500) NULL,
	[gender] [varchar](200) NULL,
	[age] [varchar](100) NULL,
	[address] [varchar](1000) NULL,
	[city] [varchar](300) NULL,
	[country] [varchar](300) NULL,
	[phone] [varchar](50) NULL,
	[username] [varchar](300) NULL,
	[password] [varchar](300) NULL,
	[question] [varchar](3000) NULL,
	[answer] [varchar](300) NULL
) ON [PRIMARY]
GO


CREATE TABLE [dbo].[Certifications](
	[UserName] [varchar](100) NULL,
	[Certification] [varchar](8000) NULL,
	[Role] [varchar](8000) NULL,
	[Description] [varchar](8000) NULL,
	[Results] [varchar](300) NULL,
	[Dated] [varchar](100) NULL,
	[Skills] [varchar](3000) NULL
) ON [PRIMARY]
GO


CREATE TABLE [dbo].[Jobs](
	[EmployerName] [varchar](1000) NULL,
	[JobTitle] [varchar](1000) NULL,
	[CompanyName] [varchar](8000) NULL,
	[CompanyInfo] [varchar](8000) NULL,
	[JobDescription] [varchar](8000) NULL,
	[JobResponsibilities] [varchar](8000) NULL,
	[SkillsRequired] [varchar](8000) NULL,
	[City] [varchar](800) NULL,
	[Province] [varchar](800) NULL,
	[ExperienceRequired] [varchar](1000) NULL,
	[WillingToMove] [varchar](1000) NULL,
	[Salary] [varchar](1000) NULL
) ON [PRIMARY]
GO


CREATE TABLE [dbo].[JobSeeker](
	[name] [varchar](500) NULL,
	[gender] [varchar](200) NULL,
	[age] [varchar](100) NULL,
	[address] [varchar](1000) NULL,
	[city] [varchar](300) NULL,
	[country] [varchar](300) NULL,
	[phone] [varchar](50) NULL,
	[username] [varchar](300) NULL,
	[password] [varchar](300) NULL,
	[question] [varchar](3000) NULL,
	[answer] [varchar](300) NULL
) ON [PRIMARY]
GO


CREATE TABLE [dbo].[Projects](
	[UserName] [varchar](100) NULL,
	[ProjectTitle] [varchar](8000) NULL,
	[ProjectDescription] [varchar](8000) NULL,
	[ProgrammingLanguages] [varchar](8000) NULL,
	[TeamMembers] [varchar](300) NULL,
	[Skills] [varchar](3000) NULL
) ON [PRIMARY]
GO
CREATE TABLE [dbo].[Skills](
	[UserName] [varchar](100) NULL,
	[TechnicalSkills] [varchar](8000) NULL,
	[SoftSkills] [varchar](8000) NULL
) ON [PRIMARY]
GO


CREATE TABLE [dbo].[VolunteerExperience](
	[UserName] [varchar](100) NULL,
	[CompanyName] [varchar](8000) NULL,
	[JobPosition] [varchar](8000) NULL,
	[JobDescription] [varchar](8000) NULL,
	[StartDate] [varchar](300) NULL,
	[EndDate] [varchar](3000) NULL
) ON [PRIMARY]
GO


CREATE TABLE [dbo].[WorkExperience](
	[UserName] [varchar](100) NULL,
	[CompanyName] [varchar](8000) NULL,
	[JobPosition] [varchar](8000) NULL,
	[JobDescription] [varchar](8000) NULL,
	[StartDate] [varchar](300) NULL,
	[EndDate] [varchar](3000) NULL
) ON [PRIMARY]
GO
