﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GroupProject
{
    public partial class AdminForgotPassword : Form
    {
        string password = string.Empty;
        private class ComboBoxItem
        {
            public int Value { get; set; }
            public string Text { get; set; }
            public bool Selectable { get; set; }
        }
        public AdminForgotPassword()
        {
            InitializeComponent();
        }

        private void AdminForgotPassword_Load(object sender, EventArgs e)
        {
            this.securityQuestion.ValueMember = "Value";
            this.securityQuestion.DisplayMember = "Text";
            this.securityQuestion.Items.AddRange(new[] {
            new ComboBoxItem() { Selectable = false, Text="Security Question:", Value=0},
            new ComboBoxItem() { Selectable = true, Text="What Is your favorite book?", Value=1},
            new ComboBoxItem() { Selectable = true, Text="What is the name of the road you grew up on?", Value=2},
            new ComboBoxItem() { Selectable = true, Text="What is your mother's maiden name?", Value=3},
            new ComboBoxItem() { Selectable = true, Text="What was the name of your first/current/favorite pet?", Value=4},
            new ComboBoxItem() { Selectable = true, Text="What was the first company that you worked for?", Value=5},
            new ComboBoxItem() { Selectable = true, Text="Where did you meet your spouse? ", Value=6},
            new ComboBoxItem() { Selectable = true, Text="Where did you go to high school/college?", Value=7},
            new ComboBoxItem() { Selectable = true, Text="What is your favorite food?", Value=8},
            new ComboBoxItem() { Selectable = true, Text="What city were you born in?", Value=9},
            new ComboBoxItem() { Selectable = true, Text="Where is your favorite place to vacation?", Value=10},
        });
            securityQuestion.SelectedIndex = 0;
            this.securityQuestion.SelectedIndexChanged += (cbSender, cbe) =>
            {
                var cb = cbSender as ComboBox;

                if (cb.SelectedItem != null && cb.SelectedItem is ComboBoxItem && ((ComboBoxItem)cb.SelectedItem).Selectable == false)
                {
                    // deselect item
                    cb.SelectedIndex = -1;
                }
            };
        }

        private void Back_Click(object sender, EventArgs e)
        {
            Form1 x = new Form1();
            x.Show();
            this.Hide();
        }

        private void Exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void userName_Enter(object sender, EventArgs e)
        {
            if (userName.Text == "User Name")
            {
                userName.Text = "";
                userName.ForeColor = Color.Black;
            }
        }

        private void userName_Leave(object sender, EventArgs e)
        {
            if (userName.Text == "")
            {
                userName.Text = "User Name";
                userName.ForeColor = Color.Gray;
            }
        }

        private void securityAnswer_Enter(object sender, EventArgs e)
        {
            if (securityAnswer.Text == "Security Answer")
            {
                securityAnswer.Text = "";
                securityAnswer.ForeColor = Color.Black;
            }
        }

        private void securityAnswer_Leave(object sender, EventArgs e)
        {
            if (securityAnswer.Text == "")
            {
                securityAnswer.Text = "Security Answer";
                securityAnswer.ForeColor = Color.Gray;
            }
        }

        private void GetPassword_Click(object sender, EventArgs e)
        {
            string user = userName.Text;
            string secQues = securityQuestion.Text;
            string secAns = securityAnswer.Text;

            if (ForgotPass(user,  secAns))
            {

                Form1 wp = new Form1();
                MessageBox.Show($"Dear {user}, Your password is: {password}");
                wp.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Invalid credentials");
                Form1 wp = new Form1();
                wp.Show();
                this.Hide();
            }

        }

        public bool ForgotPass(string user,  string secAns)
        {
            bool flag=true;
            if (user != null && secAns != null )
            {
                SqlConnection con = new SqlConnection(Form1.sqlConnectionString);
                con.Open();
                string query = $"select password from Admin where username='{user}'  and answer='{secAns}'";
                SqlCommand cmd = new SqlCommand(query, con);

                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    password = dr["password"].ToString();
                    //MessageBox.Show($"Dear {user}, Your password is: {password}");
                    flag = true;
                    return flag;
                }
                else
                {
                    flag = false;
                    return flag ;
                }
            }
            else
            {
                MessageBox.Show("Please enter Username and Security answer");
            }
            return flag;
        }

    }
}
