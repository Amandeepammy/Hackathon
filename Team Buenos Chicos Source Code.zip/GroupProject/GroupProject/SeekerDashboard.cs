﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GroupProject
{
    public partial class SeekerDashboard : Form
    {
        public SeekerDashboard()
        {
            InitializeComponent();
        }

        private void SeekerDashboard_Load(object sender, EventArgs e)
        {
            label1.Text = "Welcome "+JobSeekerLogin.user+"!";
        }

        private void button7_Click(object sender, EventArgs e)
        {
            JobSeekerLogin.user = "";
            AdminMainPage s = new AdminMainPage();
            s.Show();
            this.Hide();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void addAcademics_Click(object sender, EventArgs e)
        {
            AddAcademics x = new AddAcademics();
            x.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            AddProjects x = new AddProjects();
            x.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            AddWEx x = new AddWEx();
            x.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            AddVEx x = new AddVEx();
            x.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            AddCertification x = new AddCertification();
            x.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            AddSkills x = new AddSkills();
            x.Show();
            this.Hide();
        }
    }
}
