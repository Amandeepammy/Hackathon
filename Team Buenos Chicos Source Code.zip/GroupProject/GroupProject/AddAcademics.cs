﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GroupProject
{
    public partial class AddAcademics : Form
    {
        public AddAcademics()
        {
            InitializeComponent();
        }

        private void textBox1_Enter(object sender, EventArgs e)
        {
            if (textBox1.Text == "Institution Name")
            {
                textBox1.Text = "";
                textBox1.ForeColor = Color.Black;
            }
        }

        private void textBox1_Leave(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                textBox1.Text = "Institution Name";
                textBox1.ForeColor = Color.Black;
            }
        }
        private class ComboBoxItem
        {
            public int Value { get; set; }
            public string Text { get; set; }
            public bool Selectable { get; set; }
        }
        private void AddAcademics_Load(object sender, EventArgs e)
        {
            Reset();
            this.comboBox1.ValueMember = "Value";
            this.comboBox1.DisplayMember = "Text";
            this.comboBox1.Items.AddRange(new[] {
            new ComboBoxItem() { Selectable = false, Text="Level of Education:", Value=0},
            new ComboBoxItem() { Selectable = true, Text="High School", Value=1},
            new ComboBoxItem() { Selectable = true, Text="Post Secondary Diploma", Value=2},
            new ComboBoxItem() { Selectable = true, Text="Bachelor's Degree", Value=3},
            new ComboBoxItem() { Selectable = true, Text="Post Graduatation Diploma", Value=4},
            new ComboBoxItem() { Selectable = true, Text="Master's Degree", Value=5},
            new ComboBoxItem() { Selectable = true, Text="Doctorate", Value=6},
        });
            comboBox1.SelectedIndex = 0;
            this.comboBox1.SelectedIndexChanged += (cbSender, cbe) =>
            {
                var cb = cbSender as ComboBox;

                if (cb.SelectedItem != null && cb.SelectedItem is ComboBoxItem && ((ComboBoxItem)cb.SelectedItem).Selectable == false)
                {
                    cb.SelectedIndex = -1;
                }
            };
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SeekerDashboard x = new SeekerDashboard();
            x.Show();
            this.Hide();
        }

        private void textBox2_Enter(object sender, EventArgs e)
        {
            if (textBox2.Text == "Program Name")
            {
                textBox2.Text = "";
                textBox2.ForeColor = Color.Black;
            }
        }

        private void textBox2_Leave(object sender, EventArgs e)
        {
            if (textBox2.Text == "")
            {
                textBox2.Text = "Program Name";
                textBox2.ForeColor = Color.Black;
            }
        }

        private void textBox3_Enter(object sender, EventArgs e)
        {
            if (textBox3.Text == "Grades/ Marks")
            {
                textBox3.Text = "";
                textBox3.ForeColor = Color.Black;
            }
        }

        private void textBox3_Leave(object sender, EventArgs e)
        {
            if (textBox3.Text == "")
            {
                textBox3.Text = "Grades/ Marks";
                textBox3.ForeColor = Color.Black;
            }
        }

        private void textBox4_Enter(object sender, EventArgs e)
        {
            if (textBox4.Text == "Institution Address")
            {
                textBox4.Text = "";
                textBox4.ForeColor = Color.Black;
            }
        }

        private void textBox4_Leave(object sender, EventArgs e)
        {
            if (textBox4.Text == "")
            {
                textBox4.Text = "Institution Address";
                textBox4.ForeColor = Color.Black;
            }
        }

        private void textBox5_Enter(object sender, EventArgs e)
        {
            if (textBox5.Text == "Year Started")
            {
                textBox5.Text = "";
                textBox5.ForeColor = Color.Black;
            }
        }

        private void textBox5_Leave(object sender, EventArgs e)
        {
            if (textBox5.Text == "")
            {
                textBox5.Text = "Year Started";
                textBox5.ForeColor = Color.Black;
            }
        }

        private void textBox6_Enter(object sender, EventArgs e)
        {
            if (textBox6.Text == "Year Completed")
            {
                textBox6.Text = "";
                textBox6.ForeColor = Color.Black;
            }
        }

        private void textBox6_Leave(object sender, EventArgs e)
        {
            if (textBox6.Text == "")
            {
                textBox6.Text = "Year Completed";
                textBox6.ForeColor = Color.Black;
            }
        }

        public void Reset()
        {
            comboBox1.SelectedIndex = -1;
            textBox1.Text = "Institution Name";
            textBox2.Text = "Program Name";
            textBox3.Text = "Grades/ Marks";
            textBox4.Text = "Institution Address";
            textBox5.Text = "Year Started";
            textBox6.Text = "Year Completed";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string a = textBox1.Text;
            string b = textBox2.Text;
            string c = textBox3.Text;
            string d = textBox4.Text;
            string x = textBox5.Text;
            string y = textBox6.Text;
            string z = (string)comboBox1.Text;
            string user = JobSeekerLogin.user;
                if (Registration(a,b,c,d,x,y,z,user))
                {
                    MessageBox.Show("Data Inserted");
                    SeekerDashboard xx = new SeekerDashboard();
                    xx.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Data not inserted");
                }
        }
        public bool Registration(string a, string b, string c, string d, string x, string y, string z,string user)
        {
                try
                {
                        SqlConnection con = new SqlConnection(Form1.sqlConnectionString);
                        con.Open();
                        string query = "insert into Academics(UserName,LevelOfEducation,InstitutionName,ProgramName,GradesOrMarks,InstitutionAddress,YearStarted,YearCompleted) " +
                            "values('" + user + "','" + z + "','" + a + "','" + b + "','" + c + "','" + d + "','" + x + "', '" + y + "')";
                        SqlCommand cmd = new SqlCommand(query, con);
                        int az = cmd.ExecuteNonQuery();
                        if (az > 0)
                        {
                            return true;
                        }
                        else
                        {
                            return false;
                        }  
                }

                catch (MySql.Data.MySqlClient.MySqlException ex)
                {
                    return false;
                }
        }
    

        private void button3_Click(object sender, EventArgs e)
        {
            string a = textBox1.Text; 
            string b = textBox2.Text;
            string c = textBox3.Text;
            string d = textBox4.Text;
            string x = textBox5.Text;
            string y = textBox6.Text;
            string z = (string)comboBox1.Text;
            string user = JobSeekerLogin.user;
            if (Registration(a, b, c, d, x, y, z, user))
            {
                MessageBox.Show("Data Inserted");
                Reset();
            }
            else
            {
                MessageBox.Show("Data not inserted");
            }
        }
    }
}
