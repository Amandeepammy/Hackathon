﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GroupProject
{
    public partial class AdminMainPage : Form
    {
        DataSet ds = new DataSet();
        SqlConnection cs = new SqlConnection(Form1.sqlConnectionString);
        public AdminMainPage()
        {
            InitializeComponent();
            dg.Hide();
        }

        private void AdminMainPage_Load(object sender, EventArgs e)
        {

        }

        private void FindJobs_Click(object sender, EventArgs e)
        {
            dg.Show();
            string jobPost = textBox1.Text;
            string loc = textBox2.Text;
            if(jobPost!=null && loc != null)
            {
                using (SqlConnection sqlCon = new SqlConnection(Form1.sqlConnectionString))
                {
                    sqlCon.Open();
                    SqlDataAdapter sqlDa = new SqlDataAdapter($"Select JobTitle, CompanyName, JobDescription,SkillsRequired, City, Province,Salary from Jobs where (JobTitle like '%{textBox1.Text}%' or JobDescription like '%{textBox1.Text}%' or SkillsRequired like '%{textBox1.Text}%' or CompanyName like '%{textBox1.Text}%') and (City like '%{textBox2.Text}%' or Province like '%{textBox2.Text}%')", sqlCon);
                    DataTable x = new DataTable();
                    sqlDa.Fill(x);
                    dg.DataSource = x;
                }
            }
            else if (jobPost != null && loc ==null)
            {
                using (SqlConnection sqlCon = new SqlConnection(Form1.sqlConnectionString))
                {
                    sqlCon.Open();
                    SqlDataAdapter sqlDa = new SqlDataAdapter($"Select JobTitle, CompanyName, JobDescription,SkillsRequired, City, Province,Salary from Jobs where JobTitle like '%{textBox1.Text}%' or JobDescription like '%{textBox1.Text}%' or SkillsRequired like '%{textBox1.Text}%' or CompanyName like '%{textBox1.Text}%' ", sqlCon);
                    DataTable x = new DataTable();
                    sqlDa.Fill(x);
                    dg.DataSource = x;
                }
            }
            else if(jobPost==null && loc != null)
            {
                using (SqlConnection sqlCon = new SqlConnection(Form1.sqlConnectionString))
                {
                    sqlCon.Open();
                    SqlDataAdapter sqlDa = new SqlDataAdapter($"Select JobTitle, CompanyName, JobDescription,SkillsRequired, City, Province,Salary from Jobs where City like '%{textBox2.Text}%' or Province like '%{textBox2.Text}%'", sqlCon);
                    DataTable x = new DataTable();
                    sqlDa.Fill(x);
                    dg.DataSource = x;
                }
            }
            else
            {
                using (SqlConnection sqlCon = new SqlConnection(Form1.sqlConnectionString))
                {
                    sqlCon.Open();
                    SqlDataAdapter sqlDa = new SqlDataAdapter("Select JobTitle, CompanyName, JobDescription,SkillsRequired, City, Province,Salary from Jobs", sqlCon);
                    DataTable x = new DataTable();
                    sqlDa.Fill(x);
                    dg.DataSource = x;
                }
            }
        }

        private void UpdateProfile_Click(object sender, EventArgs e)
        {
            JobSeekerLogin s = new JobSeekerLogin();
            s.Show();
            this.Hide();
        }

        private void JobPost_Click(object sender, EventArgs e)
        {
            Form1 x = new Form1();
            x.Show();
            this.Hide();
        }
    }
}
