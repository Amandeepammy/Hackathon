﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GroupProject
{
    public partial class EmployerDashboard : Form
    {
        public EmployerDashboard()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            AdminMainPage x = new AdminMainPage();
            x.Show();
            this.Hide();
      
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            JobPost x = new JobPost();
            x.Show();
            this.Hide();
        }

        private void EmployerDashboard_Load(object sender, EventArgs e)
        {
            label1.Text = "Welcome " + Form1.user + "!";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ViewPostedJobs x = new ViewPostedJobs();
            x.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            ViewJobSeekers x = new ViewJobSeekers();
            x.Show();
            this.Hide();
        }
    }
}
