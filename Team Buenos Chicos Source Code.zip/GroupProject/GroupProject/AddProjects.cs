﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GroupProject
{
    public partial class AddProjects : Form
    {
        public AddProjects()
        {
            InitializeComponent();


        }
        private class ComboBoxItem
        {
            public int Value { get; set; }
            public string Text { get; set; }
            public bool Selectable { get; set; }
        }

        private void AddProjects_Load(object sender, EventArgs e)
        {
            this.comboBox1.ValueMember = "Value";
            this.comboBox1.DisplayMember = "Text";
            this.comboBox1.Items.AddRange(new[] {
            new ComboBoxItem() { Selectable = false, Text="Numbers of Team Members:", Value=0},
            new ComboBoxItem() { Selectable = true, Text="Individual Project", Value=1},
            new ComboBoxItem() { Selectable = true, Text="2-5 Members", Value=2},
            new ComboBoxItem() { Selectable = true, Text="5-10 Members", Value=3},
            new ComboBoxItem() { Selectable = true, Text="10+ Members", Value=4},
        });
            comboBox1.SelectedIndex = 0;
            this.comboBox1.SelectedIndexChanged += (cbSender, cbe) =>
            {
                var cb = cbSender as ComboBox;

                if (cb.SelectedItem != null && cb.SelectedItem is ComboBoxItem && ((ComboBoxItem)cb.SelectedItem).Selectable == false)
                {
                    cb.SelectedIndex = -1;
                }
            };
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SeekerDashboard x = new SeekerDashboard();
            x.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string a = textBox1.Text;//title
            string b = richTextBox1.Text;//desc
            string c = richTextBox2.Text;//PL
            string z = (string)comboBox1.Text;
            string user = JobSeekerLogin.user;
            if (Registration(a, b, c, z, user))
            {
                MessageBox.Show("Data Inserted");
                SeekerDashboard xx = new SeekerDashboard();
                xx.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Data not inserted");
            }
        }
        public bool Registration(string a, string b, string c, string z, string user)
        {
            string skills = "";
            if (z == "Individual Project")
            {
                skills = "Good Communication, Pressure Handler, Initiator, Pro-active, Good Speaker, Creator, Quick-Learner, Independent, Adaptability, Flexibility, Problem-solving";
                
            }
            else
            {
                skills = "Team-Player, Leadership, Good Communication, Pressure Handler, Initiator, Pro-active, Good Speaker, Good Team-Work, Creator, Quick-Learner, Agility, Independent, Adaptability, Conflict resolution, Flexibility, Problem-solving, Integrity";
            }
            try
            {
                SqlConnection con = new SqlConnection(Form1.sqlConnectionString);
                con.Open();
                string query = "insert into Projects(UserName,ProjectTitle,ProjectDescription,ProgrammingLanguages,TeamMembers,Skills) " +
                    "values('" + user + "','" + a + "','" + b + "','" + c + "','" + z + "','" + skills + "')";
                SqlCommand cmd = new SqlCommand(query, con);
                int az = cmd.ExecuteNonQuery();
                if (az > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }

            catch (MySql.Data.MySqlClient.MySqlException ex)
            {
                return false;
            }
        }
    

        private void button3_Click(object sender, EventArgs e)
        {
            string a = textBox1.Text;//title
            string b = richTextBox1.Text;//desc
            string c = richTextBox2.Text;//PL
            string z = (string)comboBox1.Text;
            string user = JobSeekerLogin.user;
            if (Registration(a, b, c, z, user))
            {
                MessageBox.Show("Data Inserted");
                Reset();
            }
            else
            {
                MessageBox.Show("Data not inserted");
            }
        }
        public void Reset()
        {
            textBox1.Text = "";
            richTextBox1.Text = "";
            richTextBox2.Text = "";
            comboBox1.SelectedIndex = 0;
        }
    }
}
