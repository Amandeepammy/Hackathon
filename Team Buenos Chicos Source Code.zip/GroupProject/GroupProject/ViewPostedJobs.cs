﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GroupProject
{
    public partial class ViewPostedJobs : Form
    {
        DataSet ds = new DataSet();
        SqlConnection cs = new SqlConnection(Form1.sqlConnectionString);
        public ViewPostedJobs()
        {
            InitializeComponent();
            label1.Text = "Jobs Posted By " + Form1.user + " are below:";
        }

        private void ViewPostedJobs_Load(object sender, EventArgs e)
        {
            dg.Show();
            if (log(Form1.user))
            {
                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = new SqlCommand($"Select JobTitle, CompanyName, JobDescription,SkillsRequired, City, Province,Salary from Jobs where Employername='{Form1.user}'", cs);
                da.Fill(ds);
                dg.DataSource = ds.Tables[0];
            }
        }
        public bool log(string s)
        {
            string query = $"Select JobTitle, CompanyName, JobDescription,SkillsRequired, City, Province,Salary from Jobs where Employername='{s}'";
            SqlCommand cmd = new SqlCommand(query, cs);
            cs.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                cs.Close();
                return true;
            }
            else
            {
                return false;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            EmployerDashboard x = new EmployerDashboard();
            x.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
