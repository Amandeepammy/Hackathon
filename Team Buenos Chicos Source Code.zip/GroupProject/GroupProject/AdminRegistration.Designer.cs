﻿namespace GroupProject
{
    partial class AdminRegistration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Register = new System.Windows.Forms.Button();
            this.Back = new System.Windows.Forms.Button();
            this.securityQuestion = new System.Windows.Forms.ComboBox();
            this.gender = new System.Windows.Forms.ComboBox();
            this.country = new System.Windows.Forms.TextBox();
            this.userName = new System.Windows.Forms.TextBox();
            this.phoneNumber = new System.Windows.Forms.TextBox();
            this.city = new System.Windows.Forms.TextBox();
            this.address = new System.Windows.Forms.TextBox();
            this.age = new System.Windows.Forms.TextBox();
            this.cPassword = new System.Windows.Forms.TextBox();
            this.securityAnswer = new System.Windows.Forms.TextBox();
            this.password = new System.Windows.Forms.TextBox();
            this.name = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // Register
            // 
            this.Register.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Register.Location = new System.Drawing.Point(317, 482);
            this.Register.Name = "Register";
            this.Register.Size = new System.Drawing.Size(206, 39);
            this.Register.TabIndex = 8;
            this.Register.Text = "Register";
            this.Register.UseVisualStyleBackColor = true;
            this.Register.Click += new System.EventHandler(this.Register_Click);
            // 
            // Back
            // 
            this.Back.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Back.Location = new System.Drawing.Point(43, 482);
            this.Back.Name = "Back";
            this.Back.Size = new System.Drawing.Size(206, 39);
            this.Back.TabIndex = 7;
            this.Back.Text = "Back";
            this.Back.UseVisualStyleBackColor = true;
            this.Back.Click += new System.EventHandler(this.Back_Click);
            // 
            // securityQuestion
            // 
            this.securityQuestion.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.securityQuestion.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.securityQuestion.FormattingEnabled = true;
            this.securityQuestion.Location = new System.Drawing.Point(43, 369);
            this.securityQuestion.Name = "securityQuestion";
            this.securityQuestion.Size = new System.Drawing.Size(480, 28);
            this.securityQuestion.TabIndex = 6;
            // 
            // gender
            // 
            this.gender.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.gender.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gender.FormattingEnabled = true;
            this.gender.Location = new System.Drawing.Point(317, 48);
            this.gender.Name = "gender";
            this.gender.Size = new System.Drawing.Size(206, 28);
            this.gender.TabIndex = 6;
            // 
            // country
            // 
            this.country.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.country.ForeColor = System.Drawing.Color.Gray;
            this.country.Location = new System.Drawing.Point(317, 182);
            this.country.Name = "country";
            this.country.Size = new System.Drawing.Size(206, 27);
            this.country.TabIndex = 5;
            this.country.Text = "Country";
            this.country.Enter += new System.EventHandler(this.country_Enter);
            this.country.Leave += new System.EventHandler(this.country_Leave);
            // 
            // userName
            // 
            this.userName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.userName.ForeColor = System.Drawing.Color.Gray;
            this.userName.Location = new System.Drawing.Point(317, 248);
            this.userName.Name = "userName";
            this.userName.Size = new System.Drawing.Size(206, 27);
            this.userName.TabIndex = 5;
            this.userName.Text = "User Name";
            this.userName.Enter += new System.EventHandler(this.userName_Enter);
            this.userName.Leave += new System.EventHandler(this.userName_Leave);
            // 
            // phoneNumber
            // 
            this.phoneNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.phoneNumber.ForeColor = System.Drawing.Color.Gray;
            this.phoneNumber.Location = new System.Drawing.Point(43, 248);
            this.phoneNumber.Name = "phoneNumber";
            this.phoneNumber.Size = new System.Drawing.Size(206, 27);
            this.phoneNumber.TabIndex = 5;
            this.phoneNumber.Text = "Phone Number";
            this.phoneNumber.Enter += new System.EventHandler(this.phoneNumber_Enter);
            this.phoneNumber.Leave += new System.EventHandler(this.phoneNumber_Leave);
            // 
            // city
            // 
            this.city.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.city.ForeColor = System.Drawing.Color.Gray;
            this.city.Location = new System.Drawing.Point(43, 182);
            this.city.Name = "city";
            this.city.Size = new System.Drawing.Size(206, 27);
            this.city.TabIndex = 5;
            this.city.Text = "City";
            this.city.Enter += new System.EventHandler(this.city_Enter);
            this.city.Leave += new System.EventHandler(this.city_Leave);
            // 
            // address
            // 
            this.address.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.address.ForeColor = System.Drawing.Color.Gray;
            this.address.Location = new System.Drawing.Point(317, 116);
            this.address.Name = "address";
            this.address.Size = new System.Drawing.Size(206, 27);
            this.address.TabIndex = 5;
            this.address.Text = "Address";
            this.address.Enter += new System.EventHandler(this.address_Enter);
            this.address.Leave += new System.EventHandler(this.address_Leave);
            // 
            // age
            // 
            this.age.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.age.ForeColor = System.Drawing.Color.Gray;
            this.age.Location = new System.Drawing.Point(43, 116);
            this.age.Name = "age";
            this.age.Size = new System.Drawing.Size(206, 27);
            this.age.TabIndex = 5;
            this.age.Text = "Age";
            this.age.Enter += new System.EventHandler(this.age_Enter);
            this.age.Leave += new System.EventHandler(this.age_Leave);
            // 
            // cPassword
            // 
            this.cPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cPassword.ForeColor = System.Drawing.Color.Gray;
            this.cPassword.Location = new System.Drawing.Point(317, 307);
            this.cPassword.Name = "cPassword";
            this.cPassword.Size = new System.Drawing.Size(206, 27);
            this.cPassword.TabIndex = 5;
            this.cPassword.Text = "Confirm Password";
            this.cPassword.Enter += new System.EventHandler(this.cPassword_Enter);
            this.cPassword.Leave += new System.EventHandler(this.cPassword_Leave);
            // 
            // securityAnswer
            // 
            this.securityAnswer.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.securityAnswer.ForeColor = System.Drawing.Color.Gray;
            this.securityAnswer.Location = new System.Drawing.Point(43, 422);
            this.securityAnswer.Name = "securityAnswer";
            this.securityAnswer.Size = new System.Drawing.Size(480, 27);
            this.securityAnswer.TabIndex = 5;
            this.securityAnswer.Text = "Security Answer";
            this.securityAnswer.Enter += new System.EventHandler(this.securityAnswer_Enter);
            this.securityAnswer.Leave += new System.EventHandler(this.securityAnswer_Leave);
            // 
            // password
            // 
            this.password.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.password.ForeColor = System.Drawing.Color.Gray;
            this.password.Location = new System.Drawing.Point(43, 307);
            this.password.Name = "password";
            this.password.Size = new System.Drawing.Size(206, 27);
            this.password.TabIndex = 5;
            this.password.Text = "Password";
            this.password.Enter += new System.EventHandler(this.password_Enter);
            this.password.Leave += new System.EventHandler(this.password_Leave);
            // 
            // name
            // 
            this.name.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.name.ForeColor = System.Drawing.Color.Gray;
            this.name.Location = new System.Drawing.Point(43, 48);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(206, 27);
            this.name.TabIndex = 5;
            this.name.Text = "Name";
            this.name.Enter += new System.EventHandler(this.name_Enter);
            this.name.Leave += new System.EventHandler(this.name_Leave);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Register);
            this.groupBox1.Controls.Add(this.Back);
            this.groupBox1.Controls.Add(this.securityQuestion);
            this.groupBox1.Controls.Add(this.gender);
            this.groupBox1.Controls.Add(this.country);
            this.groupBox1.Controls.Add(this.userName);
            this.groupBox1.Controls.Add(this.phoneNumber);
            this.groupBox1.Controls.Add(this.city);
            this.groupBox1.Controls.Add(this.address);
            this.groupBox1.Controls.Add(this.age);
            this.groupBox1.Controls.Add(this.cPassword);
            this.groupBox1.Controls.Add(this.securityAnswer);
            this.groupBox1.Controls.Add(this.password);
            this.groupBox1.Controls.Add(this.name);
            this.groupBox1.Location = new System.Drawing.Point(436, 59);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(534, 525);
            this.groupBox1.TabIndex = 11;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Admin Registration";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::GroupProject.Properties.Resources.Admin_icon;
            this.pictureBox1.Location = new System.Drawing.Point(12, 86);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(391, 472);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 12;
            this.pictureBox1.TabStop = false;
            // 
            // AdminRegistration
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(982, 653);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.groupBox1);
            this.Name = "AdminRegistration";
            this.Text = "AdminRegistration";
            this.Load += new System.EventHandler(this.AdminRegistration_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button Register;
        private System.Windows.Forms.Button Back;
        private System.Windows.Forms.ComboBox securityQuestion;
        private System.Windows.Forms.ComboBox gender;
        private System.Windows.Forms.TextBox country;
        private System.Windows.Forms.TextBox userName;
        private System.Windows.Forms.TextBox phoneNumber;
        private System.Windows.Forms.TextBox city;
        private System.Windows.Forms.TextBox address;
        private System.Windows.Forms.TextBox age;
        private System.Windows.Forms.TextBox cPassword;
        private System.Windows.Forms.TextBox securityAnswer;
        private System.Windows.Forms.TextBox password;
        private System.Windows.Forms.TextBox name;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}