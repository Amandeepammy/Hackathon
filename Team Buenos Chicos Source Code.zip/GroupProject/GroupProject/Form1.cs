﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GroupProject
{
    public partial class Form1 : Form
    {

        public static string user, passs;
        public static string sqlConnectionString = "Data Source=Amandeep;Initial Catalog=Hackathon;Integrated Security=True";
        public Form1()
        {
            InitializeComponent();
            txtPassword.PasswordChar = '*';
        }

        private void Exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void LoginAdmin_Click(object sender, EventArgs e)
        {
            user = txtUserName.Text;
            passs = txtPassword.Text;
            if (Login(user, passs))
            {
                MessageBox.Show("Successfully Login");
                EmployerDashboard wp = new EmployerDashboard();
                wp.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Invalid credentials");
            }
        }

        public bool Login(string user, string passs)
        {
            bool flag=false;
            if (user!=null && passs!=null)
            {
                SqlConnection con = new SqlConnection(sqlConnectionString);
                con.Open();
                string query = $"select username,password from Admin where username='{user}' and password='{passs}'";
                SqlCommand cmd = new SqlCommand(query, con);

                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    flag = true;
                    return flag;
                }
                else
                {
                    flag = false;
                    return flag;
                }
            }
            return flag;
        }

        private void newAdmin_Click(object sender, EventArgs e)
        {
            AdminRegistration a = new AdminRegistration();
            a.Show();
            this.Hide();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void ForgotPassword_Click(object sender, EventArgs e)
        {
            AdminForgotPassword ad = new AdminForgotPassword();
            ad.Show();
            this.Hide();
        }
    }
}
