﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GroupProject
{
    public partial class JobPost : Form
    {
        public JobPost()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            string jobTitle = title.Text;
            string company = cname.Text;
            string companyInfo = cInfo.Text;
            string description = jDescription.Text;
            string responsibilities = jResponsibilities.Text;
            string skills = sRequired.Text;
            string city = city1.Text;
            string province = province1.Text;
            string experience = (string)exRequiredcmb.Text;
            string willingToMove = (string)willingToMovecmb.Text;
            string salary = (string)salarycmb.Text;
            try
            {
                    SqlConnection con = new SqlConnection(Form1.sqlConnectionString);
                    con.Open();
                    string query = "insert into Jobs(EmployerName,JobTitle,CompanyName,CompanyInfo,JobDescription,JobResponsibilities,SkillsRequired,City,Province,ExperienceRequired,WillingToMove,Salary) " +
                    "values('" + Form1.user + "','" + jobTitle + "','" + company + "','" + companyInfo + "','" + description + "','" + responsibilities + "','" + skills + "','" + city + "', '" + province + "','" + experience + "', '" + willingToMove + "', '" + salary + "')";
                    SqlCommand cmd = new SqlCommand(query, con);
                    int a = cmd.ExecuteNonQuery();
                    if (a > 0)
                    MessageBox.Show("Data Inserted");
                EmployerDashboard x = new EmployerDashboard();
                x.Show();
                this.Hide();

            }

            catch (MySql.Data.MySqlClient.MySqlException ex)
            {
            }

        }
        private class ComboBoxItem
        {
            public int Value { get; set; }
            public string Text { get; set; }
            public bool Selectable { get; set; }
        }

        private void JobPost_Load(object sender, EventArgs e)
        {
            this.willingToMovecmb.ValueMember = "Value";
            this.willingToMovecmb.DisplayMember = "Text";
            this.willingToMovecmb.Items.AddRange(new[] {
            new ComboBoxItem() { Selectable = false, Text=" ", Value=0},
            new ComboBoxItem() { Selectable = true, Text="Yes", Value=1},
            new ComboBoxItem() { Selectable = true, Text="No", Value=2},
                    });
            willingToMovecmb.SelectedIndex = 0;
            this.willingToMovecmb.SelectedIndexChanged += (cbSender, cbe) =>
            {
                var cb = cbSender as ComboBox;

                if (cb.SelectedItem != null && cb.SelectedItem is ComboBoxItem && ((ComboBoxItem)cb.SelectedItem).Selectable == false)
                {
                    cb.SelectedIndex = -1;
                }
            };


            this.exRequiredcmb.ValueMember = "Value";
            this.exRequiredcmb.DisplayMember = "Text";
            this.exRequiredcmb.Items.AddRange(new[] {
            new ComboBoxItem() { Selectable = false, Text=" ", Value=0},
            new ComboBoxItem() { Selectable = true, Text="0-1 Years", Value=1},
            new ComboBoxItem() { Selectable = true, Text="1-3 Years", Value=2},
            new ComboBoxItem() { Selectable = true, Text="3-5 Years", Value=3},
            new ComboBoxItem() { Selectable = true, Text="5+ Years", Value=4},
                    });
            exRequiredcmb.SelectedIndex = 0;
            this.exRequiredcmb.SelectedIndexChanged += (cbSender, cbe) =>
            {
                var cb = cbSender as ComboBox;

                if (cb.SelectedItem != null && cb.SelectedItem is ComboBoxItem && ((ComboBoxItem)cb.SelectedItem).Selectable == false)
                {
                    cb.SelectedIndex = -1;
                }
            };

            this.salarycmb.ValueMember = "Value";
            this.salarycmb.DisplayMember = "Text";
            this.salarycmb.Items.AddRange(new[] {
            new ComboBoxItem() { Selectable = false, Text=" ", Value=0},
            new ComboBoxItem() { Selectable = true, Text="$30K-$40K", Value=1},
            new ComboBoxItem() { Selectable = true, Text="$40K-$50K", Value=2},
            new ComboBoxItem() { Selectable = true, Text="$50K-$60K", Value=3},
            new ComboBoxItem() { Selectable = true, Text="$60K-$70K", Value=4},
            new ComboBoxItem() { Selectable = true, Text="$70K-$80K", Value=5},
            new ComboBoxItem() { Selectable = true, Text="$80K-$90K", Value=6},
            new ComboBoxItem() { Selectable = true, Text="$90K+", Value=7},
                    });
            salarycmb.SelectedIndex = 0;
            this.salarycmb.SelectedIndexChanged += (cbSender, cbe) =>
            {
                var cb = cbSender as ComboBox;

                if (cb.SelectedItem != null && cb.SelectedItem is ComboBoxItem && ((ComboBoxItem)cb.SelectedItem).Selectable == false)
                {
                    cb.SelectedIndex = -1;
                }
            };
        }

        private void button2_Click(object sender, EventArgs e)
        {
            title.Text="";
            cname.Text="";
            cInfo.Text="";
            jDescription.Text="";
            jResponsibilities.Text="";
            sRequired.Text="";
            city1.Text="";
            province1.Text="";
            exRequiredcmb.SelectedIndex=-1;
            willingToMovecmb.SelectedIndex=-1;
            salarycmb.SelectedIndex=-1;
        }
    }
}
