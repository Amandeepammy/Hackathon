﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GroupProject
{
    public partial class JobSeekerLogin : Form
    {
        public static string user, passs;

        public JobSeekerLogin()
        {
            InitializeComponent();
        }

        private void Exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Login_Click(object sender, EventArgs e)
        {
            string user1 = txtUserName.Text;
            string passs1 = txtPassword.Text;
            if (LoginS(user1, passs1))
            {
                MessageBox.Show("Successfully Login");
                user = user1;
                passs = passs1;
                SeekerDashboard wp = new SeekerDashboard();
                wp.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Invalid credentials");
            }
        }

        public bool LoginS(string user, string passs)
        {
            bool flag = false;
            if (user != null && passs != null)
            {
                SqlConnection con = new SqlConnection(Form1.sqlConnectionString);
                con.Open();
                string query = $"select username,password from JobSeeker where username='{user}' and password='{passs}'";
                SqlCommand cmd = new SqlCommand(query, con);

                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    flag = true;
                    return flag;
                }
                else
                {
                    flag = false;
                    return flag;
                }
            }
            return flag;
        }

        private void NewSeeker_Click(object sender, EventArgs e)
        {
            SeekerRegistration a = new SeekerRegistration();
            a.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            AdminMainPage x = new AdminMainPage();
            x.Show();
            this.Hide();
        }

        private void ForgotPassword_Click(object sender, EventArgs e)
        {
            SeekerForgotPassword ad = new SeekerForgotPassword();
            ad.Show();
            this.Hide();
        }
    }
}
