﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GroupProject
{
    public partial class AddCertification : Form
    {
        public AddCertification()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SeekerDashboard x = new SeekerDashboard();
            x.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {

            string a = company.Text;
            string b = title.Text;
            string c = role.Text;
            string x = (string)comboBox1.Text;
            string y = end.Text;
            string user = JobSeekerLogin.user;
            if (Registration(a, b, c, x, y, user))
            {
                MessageBox.Show("Data Inserted");
                SeekerDashboard xx = new SeekerDashboard();
                xx.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Data not inserted");
            }
        }
        public bool Registration(string a, string b, string c, string x, string y, string user)
        {
            string skills = "";
            if (x == "Winner")
            {
                skills = "Team-Player, Leadership, Good Communication, Pressure Handler, Initiator, Pro-active, Good Speaker, Good Team-Work, Creator, Quick-Learner, Agility, Independent, Adaptability, Conflict resolution, Flexibility, Problem-solving, Integrity";
            }
            else if (x == "Runner-Up")
            {
                skills = "Team-Player, Leadership, Good Communication, Pressure Handler, Initiator, Pro-active, Good Speaker, Good Team-Work, Creator, Quick-Learner, Adaptability, Conflict resolution, Flexibility, Problem-solving, Integrity";
            }
            else if (x == "Participation")
            {
                skills = "Team-Player, Good Communication, Initiator, Pro-active, Good Speaker, Quick-Learner, Adaptability, Conflict resolution, Integrity";
            }
            else if (x == "Learnt New Skills")
            {
                skills = "Good Communication, Initiator, Pro-active, Good Speaker, Creator, Quick-Learner, Agility, Independent, Adaptability, Conflict resolution, Flexibility, Problem-solving, Integrity";

            }
            else if (x == "Not Applicable")
            {
                skills = "N/A";
            }


            try
            {
                SqlConnection con = new SqlConnection(Form1.sqlConnectionString);
                con.Open();
                string query = "insert into Certifications(UserName,Certification,Role,Description,Results,Dated,Skills) " +
                    "values('" + user + "','" + a + "','" + b + "','" + c + "','" + x + "','" + y + "','" + skills + "')";
                SqlCommand cmd = new SqlCommand(query, con);
                int az = cmd.ExecuteNonQuery();
                if (az > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }

            catch (MySql.Data.MySqlClient.MySqlException ex)
            {
                return false;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string a = company.Text;
            string b = title.Text;
            string c = role.Text;
            string x = (string)comboBox1.Text;
            string y = end.Text;
            string user = JobSeekerLogin.user;
            if (Registration(a, b, c, x, y, user))
            {
                MessageBox.Show("Data Inserted");
                Reset();
            }
            else
            {
                MessageBox.Show("Data not inserted");
            }
        }
        public void Reset()
        {
            company.Text = "";
            title.Text = "";
            role.Text = "";
            comboBox1.SelectedIndex = 0;
            end.Text = "";
        }
        private class ComboBoxItem
        {
            public int Value { get; set; }
            public string Text { get; set; }
            public bool Selectable { get; set; }
        }
        private void AddCertification_Load(object sender, EventArgs e)
        {
            this.comboBox1.ValueMember = "Value";
            this.comboBox1.DisplayMember = "Text";
            this.comboBox1.Items.AddRange(new[] {
            new ComboBoxItem() { Selectable = false, Text="Results:", Value=0},
            new ComboBoxItem() { Selectable = true, Text="Winner", Value=1},
            new ComboBoxItem() { Selectable = true, Text="Runner-Up", Value=2},
            new ComboBoxItem() { Selectable = true, Text="Participation", Value=3},
            new ComboBoxItem() { Selectable = true, Text="Learnt New Skills", Value=4},
            new ComboBoxItem() { Selectable = true, Text="Not Applicable", Value=5},
        });
            comboBox1.SelectedIndex = 0;
            this.comboBox1.SelectedIndexChanged += (cbSender, cbe) =>
            {
                var cb = cbSender as ComboBox;

                if (cb.SelectedItem != null && cb.SelectedItem is ComboBoxItem && ((ComboBoxItem)cb.SelectedItem).Selectable == false)
                {
                    // deselect item
                    cb.SelectedIndex = -1;
                }
            };
        }
    }
}
