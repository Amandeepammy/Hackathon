﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GroupProject
{
    public partial class ViewJobSeekers : Form
    {
        public ViewJobSeekers()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            EmployerDashboard x = new EmployerDashboard();
            x.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            using (SqlConnection sqlCon = new SqlConnection(Form1.sqlConnectionString))
            {
                sqlCon.Open();
                SqlDataAdapter sqlDa = new SqlDataAdapter($"select name, gender, age, address, city, country, phone from JobSeeker where username = (select username from Skills where TechnicalSkills like '%{textBox1.Text}%' or SoftSkills like '%{textBox1.Text}%' or " +
                    $"TechnicalSkills like '%{textBox2.Text}%' or SoftSkills like '%{textBox2.Text}%' or " +
                    $"TechnicalSkills like '%{textBox3.Text}%' or SoftSkills like '%{textBox3.Text}%' or " +
                    $"TechnicalSkills like '%{textBox4.Text}%' or SoftSkills like '%{textBox4.Text}%' or " +
                    $"TechnicalSkills like '%{textBox5.Text}%' or SoftSkills like '%{textBox5.Text}%' or " +
                    $"TechnicalSkills like '%{textBox6.Text}%' or SoftSkills like '%{textBox6.Text}%')", sqlCon);
                DataTable x = new DataTable();
                sqlDa.Fill(x);
                dg.DataSource = x;
            }
        }
    }
}
