﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GroupProject
{
    public partial class AddSkills : Form
    {
        public AddSkills()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SeekerDashboard x = new SeekerDashboard();
            x.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string a = role.Text;
            string b = richTextBox1.Text;
            string user = JobSeekerLogin.user;
            if (Registration(a, b, user))
            {
                MessageBox.Show("Data Inserted");
                SeekerDashboard xx = new SeekerDashboard();
                xx.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Data not inserted");
            }
        }
        public bool Registration(string a, string b, string user)
        {
            try
            {
                SqlConnection con = new SqlConnection(Form1.sqlConnectionString);
                con.Open();
                string query = "insert into Skills(UserName,TechnicalSkills,SoftSkills) " +
                    "values('" + user + "','" + a + "','" + b + "')";
                SqlCommand cmd = new SqlCommand(query, con);
                int az = cmd.ExecuteNonQuery();
                if (az > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }

            catch (MySql.Data.MySqlClient.MySqlException ex)
            {
                return false;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string a = role.Text;
            string b = richTextBox1.Text;
            string user = JobSeekerLogin.user;
            if (Registration(a, b, user))
            {
                MessageBox.Show("Data Inserted");
                Reset();
            }
            else
            {
                MessageBox.Show("Data not inserted");
            }
        }
        public void Reset()
        {
            richTextBox1.Text = "";            
            role.Text = "";

        }
    }
}
