﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GroupProject
{
    public partial class AddVEx : Form
    {
        public AddVEx()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SeekerDashboard x = new SeekerDashboard();
            x.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {

            string a = company.Text;
            string b = title.Text;
            string c = role.Text;
            string x = start.Text;
            string y = end.Text;
            string user = JobSeekerLogin.user;
            if (Registration(a, b, c, x, y, user))
            {
                MessageBox.Show("Data Inserted");
                SeekerDashboard xx = new SeekerDashboard();
                xx.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Data not inserted");
            }
        }
        public bool Registration(string a, string b, string c, string x, string y, string user)
        {
            try
            {
                SqlConnection con = new SqlConnection(Form1.sqlConnectionString);
                con.Open();
                string query = "insert into VolunteerExperience(UserName,CompanyName,JobPosition,JobDescription,StartDate,EndDate) " +
                    "values('" + user + "','" + a + "','" + b + "','" + c + "','" + x + "','" + y + "')";
                SqlCommand cmd = new SqlCommand(query, con);
                int az = cmd.ExecuteNonQuery();
                if (az > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }

            catch (MySql.Data.MySqlClient.MySqlException ex)
            {
                return false;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string a = company.Text;
            string b = title.Text;
            string c = role.Text;
            string x = start.Text;
            string y = end.Text;
            string user = JobSeekerLogin.user;
            if (Registration(a, b, c, x, y, user))
            {
                MessageBox.Show("Data Inserted");
                Reset();
            }
            else
            {
                MessageBox.Show("Data not inserted");
            }
        }
        public void Reset()
        {
            company.Text = "";
            title.Text = "";
            role.Text = "";
            start.Text = "";
            end.Text = "";
        }
    }
}
