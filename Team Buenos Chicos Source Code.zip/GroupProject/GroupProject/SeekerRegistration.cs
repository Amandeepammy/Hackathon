﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GroupProject
{
    public partial class SeekerRegistration : Form
    {
        public SeekerRegistration()
        {
            InitializeComponent();
        }

        private void name_Enter(object sender, EventArgs e)
        {
            if (name.Text == "Name")
            {
                name.Text = "";
                name.ForeColor = Color.Black;
            }
        }

        private void name_Leave(object sender, EventArgs e)
        {
            if (name.Text == "")
            {
                name.Text = "Name";
                name.ForeColor = Color.Gray;
            }
        }

        private void age_Enter(object sender, EventArgs e)
        {
            if (age.Text == "Age")
            {
                age.Text = "";
                age.ForeColor = Color.Black;
            }
        }

        private void age_Leave(object sender, EventArgs e)
        {
            if (age.Text == "")
            {
                age.Text = "Age";
                age.ForeColor = Color.Gray;
            }
        }

        private void address_Enter(object sender, EventArgs e)
        {
            if (address.Text == "Address")
            {
                address.Text = "";
                address.ForeColor = Color.Black;
            }
        }

        private void address_Leave(object sender, EventArgs e)
        {
            if (address.Text == "")
            {
                address.Text = "Address";
                address.ForeColor = Color.Gray;
            }
        }

        private void city_Enter(object sender, EventArgs e)
        {
            if (city.Text == "City")
            {
                city.Text = "";
                city.ForeColor = Color.Black;
            }
        }

        private void city_Leave(object sender, EventArgs e)
        {
            if (city.Text == "")
            {
                city.Text = "City";
                city.ForeColor = Color.Gray;
            }
        }

        private void country_Enter(object sender, EventArgs e)
        {
            if (country.Text == "Country")
            {
                country.Text = "";
                country.ForeColor = Color.Black;
            }
        }

        private void country_Leave(object sender, EventArgs e)
        {
            if (country.Text == "")
            {
                country.Text = "Country";
                country.ForeColor = Color.Gray;
            }
        }

        private void phoneNumber_Enter(object sender, EventArgs e)
        {
            if (phoneNumber.Text == "Phone Number")
            {
                phoneNumber.Text = "";
                phoneNumber.ForeColor = Color.Black;
            }
        }


        private void phoneNumber_Leave(object sender, EventArgs e)
        {
            if (phoneNumber.Text == "")
            {
                phoneNumber.Text = "Phone Number";
                phoneNumber.ForeColor = Color.Gray;
            }
        }

        private void userName_Enter(object sender, EventArgs e)
        {
            if (userName.Text == "User Name")
            {
                userName.Text = "";
                userName.ForeColor = Color.Black;
            }
        }

        private void userName_Leave(object sender, EventArgs e)
        {
            if (userName.Text == "")
            {
                userName.Text = "User Name";
                userName.ForeColor = Color.Gray;
            }
        }

        private void password_Enter(object sender, EventArgs e)
        {
            if (password.Text == "Password")
            {

                password.Text = "";
                password.UseSystemPasswordChar = true;
                password.ForeColor = Color.Black;
            }
        }

        private void password_Leave(object sender, EventArgs e)
        {
            if (password.Text == "")
            {
                password.UseSystemPasswordChar = false;
                password.Text = "Password";
                password.ForeColor = Color.Gray;
            }
        }

        private void cPassword_Enter(object sender, EventArgs e)
        {
            if (cPassword.Text == "Confirm Password")
            {
                cPassword.Text = "";
                cPassword.UseSystemPasswordChar = true;
                cPassword.ForeColor = Color.Black;
            }
        }

        private void cPassword_Leave(object sender, EventArgs e)
        {
            if (cPassword.Text == "")
            {
                cPassword.UseSystemPasswordChar = false;
                cPassword.Text = "Confirm Password";
                cPassword.ForeColor = Color.Gray;
            }
        }

        private void securityAnswer_Enter(object sender, EventArgs e)
        {
            if (securityAnswer.Text == "Security Answer")
            {
                securityAnswer.Text = "";
                securityAnswer.ForeColor = Color.Black;
            }
        }

        private void securityAnswer_Leave(object sender, EventArgs e)
        {
            if (securityAnswer.Text == "")
            {
                securityAnswer.Text = "Security Answer";
                securityAnswer.ForeColor = Color.Gray;
            }
        }

        string name1, age1, gender1, address1, city1, country1, phone1, username1, password1, secQues, secAns;
        private class ComboBoxItem
        {
            public int Value { get; set; }
            public string Text { get; set; }
            public bool Selectable { get; set; }
        }

        private void Back_Click(object sender, EventArgs e)
        {
            JobSeekerLogin x = new JobSeekerLogin();
            x.Show();
            this.Hide();
        }

        private void Register_Click(object sender, EventArgs e)
        {
            name1 = name.Text;
            gender1 = (string)gender.Text;
            age1 = age.Text;
            address1 = address.Text;
            city1 = city.Text;
            country1 = country.Text;
            phone1 = phoneNumber.Text;
            username1 = userName.Text;
            string pass = password.Text;
            string confirmPassword = cPassword.Text;
            secQues = (string)securityQuestion.Text;
            secAns = securityAnswer.Text;



            if (pass.Equals(confirmPassword) && pass != null && confirmPassword != null && pass.Length >= 3)
            {
                password1 = pass;
                if (Registration(name1, age1, gender1, address1, city1, country1, phone1, username1, password1, secQues, secAns))
                {
                    MessageBox.Show("Data Inserted");
                    JobSeekerLogin x = new JobSeekerLogin();
                    x.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Data not inserted");
                }

            }
            else
            {
                MessageBox.Show("Password and Confirm Password are not same or of invalid length");
            }
        }

        public bool IsDigitsOnly(string str)
        {
            foreach (char c in str)
            {
                if (c < '0' || c > '9')
                    return false;
            }

            return true;
        }


        public bool Registration(string name1, string age1, string gender1, string address1, string city1, string country1, string phone1, string username1, string password1, string secQues, string secAns)
        {
            int ab;
            bool flag1 = true, flag2 = true, flag3 = true, flag4 = true, flag5 = true, flag6 = true, flag7 = true, flag8 = true, flag9 = true;
            if (name1 == null || IsDigitsOnly(name1) || name1.Length <= 2)
            {
                MessageBox.Show("Please Enter a valid Name");
                flag1 = false;
            }

            if (!(int.TryParse(age1, out ab)) || age1 == null || ab > 90 || ab < 18)
            {
                MessageBox.Show("Please Enter a valid age between 16-90 Years");
                flag2 = false;
            }
            if (address1 == null || address1.Length <= 3)
            {
                MessageBox.Show("Please Enter a valid address");
                flag3 = false;
            }
            if (city1 == null || city1.Length <= 2 || IsDigitsOnly(city1))
            {
                MessageBox.Show("Please Enter a valid city name");
                flag4 = false;
            }
            if (country1 == null || country1.Length <= 2 || IsDigitsOnly(country1))
            {
                MessageBox.Show("Please Enter a valid country name");
                flag5 = false;
            }
            if (!phone1.All(Char.IsDigit) || phone1 == null || phone1.Length < 10 || phone1.Length > 10)
            {
                MessageBox.Show("Please Enter a valid phone number");
                flag6 = false;
            }
            if (username1 == null || username1.Length <= 2)
            {
                MessageBox.Show("Please Enter a valid Username");
                flag7 = false;
            }
            if (password1 == null || password1.Length <= 3)
            {
                MessageBox.Show("Please Enter a valid password of minimun 4 digits");
                flag8 = false;
            }
            if (secAns == null || secAns.Length <= 1)
            {
                MessageBox.Show("Please Enter a valid security answer");
                flag9 = false;
            }


            bool flag = false;
            if (flag1 == true && flag2 == true && flag3 == true && flag4 == true && flag5 == true && flag6 == true && flag7 == true && flag8 == true && flag9 == true)
            {
                try
                {

                    //CheckExixtance(username1);
                    if (CheckExixtance(username1) == false)
                    {
                        SqlConnection con = new SqlConnection(Form1.sqlConnectionString);
                        con.Open();
                        string query = "insert into JobSeeker(name,gender,age,address,city,country,phone,username,password,question,answer) " +
                            "values('" + name1 + "','" + gender1 + "','" + age1 + "','" + address1 + "','" + city1 + "','" + country1 + "', '" + phone1 + "','" + username1 + "', '" + password1 + "', '" + secQues + "', '" + secAns + "')";
                        SqlCommand cmd = new SqlCommand(query, con);
                        int a = cmd.ExecuteNonQuery();
                        if (a > 0)
                        {
                            flag = true;
                            return flag;
                        }
                        else
                        {
                            flag = false;
                            return flag;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Username Already Exist");
                    }
                }

                catch (MySql.Data.MySqlClient.MySqlException ex)
                {
                    flag = false;
                    return flag;
                }

            }
            return flag;
        }

        public bool CheckExixtance(string user)
        {
            SqlConnection con = new SqlConnection(Form1.sqlConnectionString);
            con.Open();
            string query = $"select username from JobSeeker where username='{user}'";
            SqlCommand cmd = new SqlCommand(query, con);

            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private void SeekerRegistration_Load(object sender, EventArgs e)
        {
            this.securityQuestion.ValueMember = "Value";
            this.securityQuestion.DisplayMember = "Text";
            this.securityQuestion.Items.AddRange(new[] {
            new ComboBoxItem() { Selectable = false, Text="Security Question:", Value=0},
            new ComboBoxItem() { Selectable = true, Text="What Is your favorite book?", Value=1},
            new ComboBoxItem() { Selectable = true, Text="What is the name of the road you grew up on?", Value=2},
            new ComboBoxItem() { Selectable = true, Text="What is your mother's maiden name?", Value=3},
            new ComboBoxItem() { Selectable = true, Text="What was the name of your first/current/favorite pet?", Value=4},
            new ComboBoxItem() { Selectable = true, Text="What was the first company that you worked for?", Value=5},
            new ComboBoxItem() { Selectable = true, Text="Where did you meet your spouse? ", Value=6},
            new ComboBoxItem() { Selectable = true, Text="Where did you go to high school/college?", Value=7},
            new ComboBoxItem() { Selectable = true, Text="What is your favorite food?", Value=8},
            new ComboBoxItem() { Selectable = true, Text="What city were you born in?", Value=9},
            new ComboBoxItem() { Selectable = true, Text="Where is your favorite place to vacation?", Value=10},
        });
            securityQuestion.SelectedIndex = 0;
            this.securityQuestion.SelectedIndexChanged += (cbSender, cbe) =>
            {
                var cb = cbSender as ComboBox;

                if (cb.SelectedItem != null && cb.SelectedItem is ComboBoxItem && ((ComboBoxItem)cb.SelectedItem).Selectable == false)
                {
                    // deselect item
                    cb.SelectedIndex = -1;
                }
            };

            this.gender.ValueMember = "Value";
            this.gender.DisplayMember = "Text";
            this.gender.Items.AddRange(new[] {
            new ComboBoxItem() { Selectable = false, Text="Gender", Value=0},
            new ComboBoxItem() { Selectable = true, Text="Male", Value=1},
            new ComboBoxItem() { Selectable = true, Text="Female", Value=2},
                    });
            gender.SelectedIndex = 0;
            this.gender.SelectedIndexChanged += (cbSender, cbe) =>
            {
                var cb = cbSender as ComboBox;

                if (cb.SelectedItem != null && cb.SelectedItem is ComboBoxItem && ((ComboBoxItem)cb.SelectedItem).Selectable == false)
                {
                    // deselect item
                    cb.SelectedIndex = -1;
                }
            };
        }
    }
}
