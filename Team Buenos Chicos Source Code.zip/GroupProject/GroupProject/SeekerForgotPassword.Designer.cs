﻿namespace GroupProject
{
    partial class SeekerForgotPassword
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.userName = new System.Windows.Forms.TextBox();
            this.securityQuestion = new System.Windows.Forms.ComboBox();
            this.securityAnswer = new System.Windows.Forms.TextBox();
            this.GetPassword = new System.Windows.Forms.Button();
            this.Exit = new System.Windows.Forms.Button();
            this.Back = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // userName
            // 
            this.userName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.userName.ForeColor = System.Drawing.Color.Gray;
            this.userName.Location = new System.Drawing.Point(11, 22);
            this.userName.Margin = new System.Windows.Forms.Padding(2);
            this.userName.Name = "userName";
            this.userName.Size = new System.Drawing.Size(361, 23);
            this.userName.TabIndex = 8;
            this.userName.Text = "User Name";
            this.userName.Enter += new System.EventHandler(this.userName_Enter);
            this.userName.Leave += new System.EventHandler(this.userName_Leave);
            // 
            // securityQuestion
            // 
            this.securityQuestion.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.securityQuestion.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.securityQuestion.FormattingEnabled = true;
            this.securityQuestion.Location = new System.Drawing.Point(11, 87);
            this.securityQuestion.Margin = new System.Windows.Forms.Padding(2);
            this.securityQuestion.Name = "securityQuestion";
            this.securityQuestion.Size = new System.Drawing.Size(361, 25);
            this.securityQuestion.TabIndex = 7;
            // 
            // securityAnswer
            // 
            this.securityAnswer.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.securityAnswer.ForeColor = System.Drawing.Color.Gray;
            this.securityAnswer.Location = new System.Drawing.Point(11, 154);
            this.securityAnswer.Margin = new System.Windows.Forms.Padding(2);
            this.securityAnswer.Name = "securityAnswer";
            this.securityAnswer.Size = new System.Drawing.Size(361, 23);
            this.securityAnswer.TabIndex = 6;
            this.securityAnswer.Text = "Security Answer";
            this.securityAnswer.Enter += new System.EventHandler(this.securityAnswer_Enter);
            this.securityAnswer.Leave += new System.EventHandler(this.securityAnswer_Leave);
            // 
            // GetPassword
            // 
            this.GetPassword.Location = new System.Drawing.Point(202, 204);
            this.GetPassword.Margin = new System.Windows.Forms.Padding(2);
            this.GetPassword.Name = "GetPassword";
            this.GetPassword.Size = new System.Drawing.Size(169, 37);
            this.GetPassword.TabIndex = 3;
            this.GetPassword.Text = "Get Your Password";
            this.GetPassword.UseVisualStyleBackColor = true;
            this.GetPassword.Click += new System.EventHandler(this.GetPassword_Click);
            // 
            // Exit
            // 
            this.Exit.Location = new System.Drawing.Point(109, 204);
            this.Exit.Margin = new System.Windows.Forms.Padding(2);
            this.Exit.Name = "Exit";
            this.Exit.Size = new System.Drawing.Size(68, 37);
            this.Exit.TabIndex = 3;
            this.Exit.Text = "EXIT";
            this.Exit.UseVisualStyleBackColor = true;
            this.Exit.Click += new System.EventHandler(this.Exit_Click);
            // 
            // Back
            // 
            this.Back.Location = new System.Drawing.Point(11, 204);
            this.Back.Margin = new System.Windows.Forms.Padding(2);
            this.Back.Name = "Back";
            this.Back.Size = new System.Drawing.Size(68, 37);
            this.Back.TabIndex = 3;
            this.Back.Text = "Back";
            this.Back.UseVisualStyleBackColor = true;
            this.Back.Click += new System.EventHandler(this.Back_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::GroupProject.Properties.Resources.dont_know_icon;
            this.pictureBox1.Location = new System.Drawing.Point(73, 99);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(226, 251);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 14;
            this.pictureBox1.TabStop = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.userName);
            this.groupBox1.Controls.Add(this.securityQuestion);
            this.groupBox1.Controls.Add(this.securityAnswer);
            this.groupBox1.Controls.Add(this.GetPassword);
            this.groupBox1.Controls.Add(this.Exit);
            this.groupBox1.Controls.Add(this.Back);
            this.groupBox1.Location = new System.Drawing.Point(348, 99);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox1.Size = new System.Drawing.Size(379, 252);
            this.groupBox1.TabIndex = 13;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Forgot password";
            // 
            // SeekerForgotPassword
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.groupBox1);
            this.Name = "SeekerForgotPassword";
            this.Text = "SeekerForgotPassword";
            this.Load += new System.EventHandler(this.SeekerForgotPassword_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox userName;
        private System.Windows.Forms.ComboBox securityQuestion;
        private System.Windows.Forms.TextBox securityAnswer;
        private System.Windows.Forms.Button GetPassword;
        private System.Windows.Forms.Button Exit;
        private System.Windows.Forms.Button Back;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}